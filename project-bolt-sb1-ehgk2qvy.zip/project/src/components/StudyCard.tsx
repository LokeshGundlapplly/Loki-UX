import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, Users, DollarSign, Star, ArrowRight } from 'lucide-react';

interface Study {
  id: string;
  title: string;
  description: string;
  participants: number;
  maxParticipants: number;
  reward: number;
  status: string;
  duration: string;
  createdAt: string;
  category: string;
  requiredRating?: number;
}

interface StudyCardProps {
  study: Study;
  userRole: 'researcher' | 'tester';
}

export default function StudyCard({ study, userRole }: StudyCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-gray-100 text-gray-800';
      case 'draft':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const participationRate = (study.participants / study.maxParticipants) * 100;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-all duration-200 group">
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(study.status)}`}>
                {study.status}
              </span>
              <span className="px-2 py-1 bg-blue-50 text-blue-700 rounded-full text-xs font-medium">
                {study.category}
              </span>
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
              {study.title}
            </h3>
            <p className="text-gray-600 text-sm line-clamp-2 mb-4">
              {study.description}
            </p>
          </div>
        </div>

        <div className="space-y-3 mb-6">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1 text-gray-500">
                <Clock className="w-4 h-4" />
                <span>{study.duration}</span>
              </div>
              <div className="flex items-center space-x-1 text-gray-500">
                <Users className="w-4 h-4" />
                <span>{study.participants}/{study.maxParticipants}</span>
              </div>
            </div>
            <div className="flex items-center space-x-1 text-green-600 font-semibold">
              <DollarSign className="w-4 h-4" />
              <span>${study.reward}</span>
            </div>
          </div>

          {study.requiredRating && userRole === 'tester' && (
            <div className="flex items-center space-x-1 text-sm text-gray-500">
              <Star className="w-4 h-4 text-yellow-500" />
              <span>Requires {study.requiredRating}+ rating</span>
            </div>
          )}

          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-blue-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${participationRate}%` }}
            ></div>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-500">
            Created {new Date(study.createdAt).toLocaleDateString()}
          </span>
          <Link
            to={`/study/${study.id}`}
            className="inline-flex items-center space-x-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium group"
          >
            <span>{userRole === 'researcher' ? 'View Details' : 'Join Study'}</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </Link>
        </div>
      </div>
    </div>
  );
}