import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, FileText, Inbox, User, HelpCircle, MessageCircle, Brain, Sparkles } from 'lucide-react';

const navigation = [
  { name: 'Explore', href: '/explore', icon: Search },
  { name: 'My opportunities', href: '/opportunities', icon: FileText },
  { name: 'AI Insights', href: '/ai-insights', icon: Brain },
  { name: 'Inbox', href: '/inbox', icon: Inbox },
  { name: 'Profile', href: '/profile', icon: User },
];

export default function Sidebar() {
  const location = useLocation();

  return (
    <div className="w-72 bg-white/80 backdrop-blur-xl border-r border-slate-200/60 flex flex-col shadow-xl">
      {/* Logo */}
      <div className="p-8">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
            <span className="text-white font-bold text-lg">L</span>
          </div>
          <div>
            <span className="text-slate-800 text-2xl font-bold">loki</span>
            <div className="flex items-center space-x-1 mt-0.5">
              <Sparkles className="w-3 h-3 text-indigo-500" />
              <span className="text-xs text-slate-500 font-medium">AI-Powered</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-6 space-y-2">
        {navigation.map((item) => {
          const isActive = location.pathname === item.href;
          return (
            <Link
              key={item.name}
              to={item.href}
              className={`flex items-center space-x-4 px-4 py-3.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                isActive
                  ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg shadow-indigo-500/25'
                  : 'text-slate-600 hover:bg-slate-100/80 hover:text-slate-800'
              }`}
            >
              <item.icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-slate-500'}`} />
              <span>{item.name}</span>
              {item.name === 'AI Insights' && (
                <div className="ml-auto">
                  <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                </div>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Help & Support */}
      <div className="p-6 border-t border-slate-200/60">
        <button className="flex items-center space-x-4 px-4 py-3.5 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-100/80 hover:text-slate-800 transition-all duration-200 w-full">
          <HelpCircle className="w-5 h-5 text-slate-500" />
          <span>Help & support</span>
        </button>
      </div>

      {/* AI Chat Button */}
      <div className="fixed bottom-8 right-8">
        <button className="w-14 h-14 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-2xl shadow-2xl flex items-center justify-center transition-all duration-300 hover:scale-105 group">
          <MessageCircle className="w-6 h-6 group-hover:scale-110 transition-transform" />
          <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-400 rounded-full animate-pulse"></div>
        </button>
      </div>
    </div>
  );
}