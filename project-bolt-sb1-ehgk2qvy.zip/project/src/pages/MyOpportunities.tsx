import React, { useState } from 'react';
import { Calendar, Clock, DollarSign, MapPin } from 'lucide-react';

const mockOpportunities = [
  {
    id: '1',
    title: 'Mobile Banking UX Study',
    description: 'Test our new mobile banking interface and provide feedback',
    status: 'scheduled',
    date: '2025-01-20',
    time: '2:00 PM',
    duration: '45 minutes',
    payment: 75,
    type: 'Remote',
    company: 'FinTech Solutions'
  },
  {
    id: '2',
    title: 'E-commerce Checkout Flow',
    description: 'Help us improve our checkout process by testing the new user flow',
    status: 'completed',
    date: '2025-01-15',
    time: '10:00 AM',
    duration: '30 minutes',
    payment: 50,
    type: 'Video call',
    company: 'ShopEasy'
  },
  {
    id: '3',
    title: 'Social Media App Testing',
    description: 'Evaluate new features in our social media platform',
    status: 'pending',
    date: '2025-01-25',
    time: '3:30 PM',
    duration: '60 minutes',
    payment: 90,
    type: 'In-person',
    company: 'SocialTech'
  }
];

export default function MyOpportunities() {
  const [filter, setFilter] = useState('all');

  const filteredOpportunities = mockOpportunities.filter(opp => 
    filter === 'all' || opp.status === filter
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled':
        return 'bg-blue-600 text-blue-100';
      case 'completed':
        return 'bg-green-600 text-green-100';
      case 'pending':
        return 'bg-yellow-600 text-yellow-100';
      default:
        return 'bg-gray-600 text-gray-100';
    }
  };

  return (
    <div className="p-8 text-white">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-4">My opportunities</h1>
        <p className="text-gray-400">Track your scheduled and completed research sessions</p>
      </div>

      {/* Filter Tabs */}
      <div className="flex space-x-1 mb-8 bg-gray-800 rounded-lg p-1 w-fit">
        {['all', 'scheduled', 'completed', 'pending'].map((status) => (
          <button
            key={status}
            onClick={() => setFilter(status)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors capitalize ${
              filter === status
                ? 'bg-gray-700 text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            {status}
          </button>
        ))}
      </div>

      {/* Opportunities List */}
      <div className="space-y-4">
        {filteredOpportunities.map((opportunity) => (
          <div key={opportunity.id} className="bg-gray-800 rounded-2xl p-6 hover:bg-gray-750 transition-colors">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-xl font-semibold text-white">{opportunity.title}</h3>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(opportunity.status)}`}>
                    {opportunity.status}
                  </span>
                </div>
                <p className="text-gray-400 mb-3">{opportunity.description}</p>
                <p className="text-sm text-gray-500 mb-4">{opportunity.company}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
              <div className="flex items-center space-x-2 text-gray-300">
                <Calendar className="w-4 h-4" />
                <span className="text-sm">{new Date(opportunity.date).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-300">
                <Clock className="w-4 h-4" />
                <span className="text-sm">{opportunity.time} ({opportunity.duration})</span>
              </div>
              <div className="flex items-center space-x-2 text-green-400">
                <DollarSign className="w-4 h-4" />
                <span className="text-sm font-medium">${opportunity.payment}</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-300">
                <MapPin className="w-4 h-4" />
                <span className="text-sm">{opportunity.type}</span>
              </div>
            </div>

            <div className="flex justify-end space-x-3">
              {opportunity.status === 'scheduled' && (
                <>
                  <button className="px-4 py-2 bg-gray-700 text-gray-300 rounded-lg hover:bg-gray-600 transition-colors text-sm">
                    Reschedule
                  </button>
                  <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                    Join Session
                  </button>
                </>
              )}
              {opportunity.status === 'completed' && (
                <>
                  <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm">
                    View Results
                  </button>
                  <button className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors text-sm">
                    Download Report
                  </button>
                </>
              )}
              {opportunity.status === 'pending' && (
                <>
                  <button className="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors text-sm">
                    View Details
                  </button>
                  <button className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors text-sm">
                    Cancel
                  </button>
                </>
              )}
            </div>
          </div>
        ))}
      </div>

      {filteredOpportunities.length === 0 && (
        <div className="bg-gray-800 rounded-2xl p-12 text-center">
          <h3 className="text-xl font-medium text-gray-300 mb-3">No opportunities found</h3>
          <p className="text-gray-400 mb-6">
            {filter === 'all' 
              ? "You haven't joined any research opportunities yet"
              : `No ${filter} opportunities at the moment`
            }
          </p>
          <button className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium">
            Explore Opportunities
          </button>
        </div>
      )}
    </div>
  );
}