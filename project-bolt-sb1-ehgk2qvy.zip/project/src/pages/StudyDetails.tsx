import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { ArrowLeft, Clock, Users, DollarSign, Star, Send, CheckCircle } from 'lucide-react';

const mockStudyDetails = {
  '1': {
    id: '1',
    title: 'E-commerce Checkout Flow Usability',
    description: 'Testing the checkout process for our new e-commerce platform. Looking for feedback on user flow and pain points.',
    longDescription: 'We are redesigning our e-commerce checkout process and need detailed feedback on the user experience. This study focuses on identifying friction points, understanding user behavior during the checkout process, and gathering suggestions for improvement.',
    participants: 12,
    maxParticipants: 15,
    reward: 45,
    status: 'active',
    duration: '30 minutes',
    createdAt: '2025-01-15',
    category: 'Usability Testing',
    tasks: [
      'Navigate to the product page and add items to your cart',
      'Proceed through the checkout process',
      'Complete the payment flow (test mode)',
      'Provide feedback on any difficulties encountered'
    ],
    requirements: [
      'Must have online shopping experience',
      'Access to a computer or tablet',
      'Stable internet connection'
    ],
    researcher: {
      name: 'Dr. Sarah Johnson',
      company: 'TechCorp Inc.',
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2'
    }
  },
  '4': {
    id: '4',
    title: 'Social Media App User Flow',
    description: 'Testing new features in a social media application. We need feedback on the posting and sharing experience.',
    longDescription: 'Our social media platform is introducing new features for content creation and sharing. We need comprehensive feedback on the user flow, feature discoverability, and overall user experience.',
    participants: 5,
    maxParticipants: 12,
    reward: 50,
    status: 'active',
    duration: '35 minutes',
    createdAt: '2025-01-15',
    category: 'Social Media',
    requiredRating: 4.0,
    tasks: [
      'Create a new post with media attachments',
      'Use the new sharing features',
      'Explore the updated discovery feed',
      'Test the commenting and interaction features'
    ],
    requirements: [
      'Active social media user',
      'Smartphone or computer access',
      'Rating of 4.0 or higher'
    ],
    researcher: {
      name: 'Alex Rodriguez',
      company: 'SocialTech Labs',
      avatar: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2'
    }
  }
};

export default function StudyDetails() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [feedback, setFeedback] = useState('');
  const [rating, setRating] = useState(0);
  const [hasJoined, setHasJoined] = useState(false);
  const [hasSubmitted, setHasSubmitted] = useState(false);

  const study = mockStudyDetails[id as keyof typeof mockStudyDetails];

  if (!study) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Study not found</h1>
          <button
            onClick={() => navigate(-1)}
            className="text-blue-600 hover:text-blue-800"
          >
            Go back
          </button>
        </div>
      </div>
    );
  }

  const handleJoinStudy = () => {
    setHasJoined(true);
  };

  const handleSubmitFeedback = (e: React.FormEvent) => {
    e.preventDefault();
    if (feedback.trim() && rating > 0) {
      setHasSubmitted(true);
    }
  };

  const canJoin = user?.role === 'tester' && 
                 (!study.requiredRating || !user.rating || user.rating >= study.requiredRating) &&
                 study.participants < study.maxParticipants;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <button
        onClick={() => navigate(-1)}
        className="inline-flex items-center space-x-2 text-gray-600 hover:text-gray-800 mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back</span>
      </button>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-8 border-b border-gray-200">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-3">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  study.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  {study.status}
                </span>
                <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                  {study.category}
                </span>
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-3">{study.title}</h1>
              <p className="text-lg text-gray-600">{study.longDescription}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center space-x-2 text-gray-600">
              <Clock className="w-5 h-5" />
              <span className="font-medium">{study.duration}</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-600">
              <Users className="w-5 h-5" />
              <span className="font-medium">{study.participants}/{study.maxParticipants}</span>
            </div>
            <div className="flex items-center space-x-2 text-green-600">
              <DollarSign className="w-5 h-5" />
              <span className="font-semibold">${study.reward}</span>
            </div>
            {study.requiredRating && (
              <div className="flex items-center space-x-2 text-yellow-600">
                <Star className="w-5 h-5" />
                <span className="font-medium">{study.requiredRating}+ rating</span>
              </div>
            )}
          </div>
        </div>

        <div className="p-8">
          {/* Researcher Info */}
          <div className="bg-gray-50 rounded-lg p-6 mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Study Researcher</h3>
            <div className="flex items-center space-x-4">
              <img
                src={study.researcher.avatar}
                alt={study.researcher.name}
                className="w-12 h-12 rounded-full border-2 border-white shadow-sm"
              />
              <div>
                <div className="font-medium text-gray-900">{study.researcher.name}</div>
                <div className="text-sm text-gray-600">{study.researcher.company}</div>
              </div>
            </div>
          </div>

          {/* Tasks */}
          <div className="mb-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Study Tasks</h3>
            <div className="space-y-3">
              {study.tasks.map((task, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-medium flex-shrink-0 mt-0.5">
                    {index + 1}
                  </div>
                  <p className="text-gray-700">{task}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Requirements */}
          <div className="mb-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Requirements</h3>
            <ul className="space-y-2">
              {study.requirements.map((requirement, index) => (
                <li key={index} className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">{requirement}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Actions for Testers */}
          {user?.role === 'tester' && (
            <div className="border-t border-gray-200 pt-8">
              {!hasJoined && !hasSubmitted && (
                <div className="text-center">
                  {canJoin ? (
                    <button
                      onClick={handleJoinStudy}
                      className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium text-lg"
                    >
                      Join Study & Start Testing
                    </button>
                  ) : (
                    <div className="text-gray-600">
                      {study.participants >= study.maxParticipants ? (
                        <p>This study is full</p>
                      ) : study.requiredRating && user.rating && user.rating < study.requiredRating ? (
                        <p>You need a rating of {study.requiredRating}+ to join this study</p>
                      ) : (
                        <p>You cannot join this study</p>
                      )}
                    </div>
                  )}
                </div>
              )}

              {hasJoined && !hasSubmitted && (
                <div className="space-y-6">
                  <div className="bg-blue-50 rounded-lg p-6 border border-blue-200">
                    <h4 className="text-lg font-semibold text-blue-900 mb-2">You've joined this study!</h4>
                    <p className="text-blue-800">Complete the tasks above and then submit your feedback below.</p>
                  </div>

                  <form onSubmit={handleSubmitFeedback} className="space-y-6">
                    <div>
                      <label htmlFor="rating" className="block text-sm font-medium text-gray-700 mb-2">
                        Overall Rating *
                      </label>
                      <div className="flex space-x-2">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setRating(star)}
                            className={`p-1 ${
                              star <= rating ? 'text-yellow-400' : 'text-gray-300'
                            } hover:text-yellow-400 transition-colors`}
                          >
                            <Star className="w-8 h-8 fill-current" />
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label htmlFor="feedback" className="block text-sm font-medium text-gray-700 mb-2">
                        Detailed Feedback *
                      </label>
                      <textarea
                        id="feedback"
                        required
                        rows={6}
                        value={feedback}
                        onChange={(e) => setFeedback(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        placeholder="Share your thoughts on the user experience, any issues you encountered, suggestions for improvement, etc."
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={!feedback.trim() || rating === 0}
                      className="inline-flex items-center space-x-2 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium"
                    >
                      <Send className="w-5 h-5" />
                      <span>Submit Feedback & Earn ${study.reward}</span>
                    </button>
                  </form>
                </div>
              )}

              {hasSubmitted && (
                <div className="bg-green-50 rounded-lg p-6 border border-green-200 text-center">
                  <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                  <h4 className="text-lg font-semibold text-green-900 mb-2">Feedback Submitted!</h4>
                  <p className="text-green-800 mb-4">Thank you for your valuable feedback. Your payment of ${study.reward} will be processed within 24 hours.</p>
                  <button
                    onClick={() => navigate('/tester/dashboard')}
                    className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors font-medium"
                  >
                    Find More Studies
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}