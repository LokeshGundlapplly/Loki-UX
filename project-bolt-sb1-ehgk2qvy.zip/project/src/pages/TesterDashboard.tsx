import React, { useState } from 'react';
import { Search, Filter, Star, Clock, Users, DollarSign } from 'lucide-react';
import StudyCard from '../components/StudyCard';
import { useAuth } from '../contexts/AuthContext';

const mockAvailableStudies = [
  {
    id: '4',
    title: 'Social Media App User Flow',
    description: 'Testing new features in a social media application. We need feedback on the posting and sharing experience.',
    participants: 5,
    maxParticipants: 12,
    reward: 50,
    status: 'active',
    duration: '35 minutes',
    createdAt: '2025-01-15',
    category: 'Social Media',
    requiredRating: 4.0
  },
  {
    id: '5',
    title: 'Banking App Security Features',
    description: 'Evaluating the usability of new security features in our mobile banking application.',
    participants: 3,
    maxParticipants: 8,
    reward: 75,
    status: 'active',
    duration: '45 minutes',
    createdAt: '2025-01-14',
    category: 'FinTech',
    requiredRating: 4.5
  },
  {
    id: '6',
    title: 'E-learning Platform Navigation',
    description: 'Testing course discovery and enrollment process for our educational platform.',
    participants: 8,
    maxParticipants: 15,
    reward: 40,
    status: 'active',
    duration: '25 minutes',
    createdAt: '2025-01-13',
    category: 'Education',
    requiredRating: 3.5
  },
];

export default function TesterDashboard() {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const filteredStudies = mockAvailableStudies.filter(study => {
    const matchesSearch = study.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         study.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || study.category === categoryFilter;
    const meetsRating = !user?.rating || study.requiredRating <= user.rating;
    return matchesSearch && matchesCategory && meetsRating;
  });

  const availableStudies = mockAvailableStudies.length;
  const estimatedEarnings = mockAvailableStudies.reduce((sum, s) => sum + s.reward, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Find Studies</h1>
        <p className="text-gray-600">Discover UX studies that match your skills and earn money</p>
      </div>

      {/* Tester Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-2 bg-yellow-100 rounded-lg">
              <Star className="w-6 h-6 text-yellow-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Rating</p>
              <p className="text-2xl font-bold text-gray-900">{user?.rating?.toFixed(1) || '5.0'}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-2 bg-green-100 rounded-lg">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Earnings</p>
              <p className="text-2xl font-bold text-gray-900">${user?.totalEarnings?.toFixed(2) || '0.00'}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Clock className="w-6 h-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Completed</p>
              <p className="text-2xl font-bold text-gray-900">{user?.completedStudies || 0}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Users className="w-6 h-6 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Available</p>
              <p className="text-2xl font-bold text-gray-900">{availableStudies}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Earnings Overview */}
      <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-6 mb-8 border border-green-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Potential Earnings Available</h3>
        <p className="text-3xl font-bold text-green-600 mb-2">${estimatedEarnings}</p>
        <p className="text-sm text-gray-600">Complete all available studies to earn this amount</p>
      </div>

      {/* Search and Filter */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search studies..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div className="relative">
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="appearance-none bg-white border border-gray-300 rounded-lg px-4 py-2 pr-8 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="all">All Categories</option>
              <option value="Social Media">Social Media</option>
              <option value="FinTech">FinTech</option>
              <option value="Education">Education</option>
              <option value="E-commerce">E-commerce</option>
              <option value="Mobile UX">Mobile UX</option>
            </select>
            <Filter className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Studies Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredStudies.map((study) => (
          <StudyCard key={study.id} study={study} userRole="tester" />
        ))}
      </div>

      {filteredStudies.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Search className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No studies found</h3>
          <p className="text-gray-600">Try adjusting your search criteria or check back later for new studies</p>
        </div>
      )}
    </div>
  );
}