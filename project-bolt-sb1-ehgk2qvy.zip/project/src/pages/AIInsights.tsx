import React, { useState } from 'react';
import { Brain, TrendingUp, Target, Lightbulb, BarChart3, PieChart, Activity, Sparkles, ChevronRight, Star } from 'lucide-react';

const insights = [
  {
    id: '1',
    type: 'performance',
    title: 'Your Testing Performance',
    description: 'AI analysis of your recent testing sessions',
    score: 92,
    trend: '+8%',
    details: 'You excel at identifying usability issues and providing actionable feedback'
  },
  {
    id: '2',
    type: 'recommendations',
    title: 'Skill Development',
    description: 'AI-suggested areas for improvement',
    recommendations: ['Voice UI Testing', 'Accessibility Evaluation', 'Mobile UX'],
    potential: '+$150/month'
  },
  {
    id: '3',
    type: 'market',
    title: 'Market Opportunities',
    description: 'Trending study types in your expertise',
    categories: [
      { name: 'AI/ML Interfaces', demand: 85, growth: '+23%' },
      { name: 'Voice UI', demand: 78, growth: '+31%' },
      { name: 'AR/VR Testing', demand: 72, growth: '+45%' }
    ]
  }
];

const personalizedRecommendations = [
  {
    id: '1',
    title: 'Complete AI Certification',
    description: 'Unlock higher-paying AI/ML testing opportunities',
    impact: 'High',
    timeToComplete: '2 weeks',
    potentialIncrease: '$200/month'
  },
  {
    id: '2',
    title: 'Improve Response Time',
    description: 'Faster responses lead to more study invitations',
    impact: 'Medium',
    timeToComplete: 'Immediate',
    potentialIncrease: '15% more invites'
  }
];

export default function AIInsights() {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="p-8 text-slate-800 min-h-screen">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center space-x-3 mb-2">
          <div className="p-2 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent">
            AI Insights
          </h1>
          <div className="px-3 py-1 bg-gradient-to-r from-emerald-100 to-emerald-50 border border-emerald-200 rounded-full">
            <span className="text-xs font-medium text-emerald-700">Beta</span>
          </div>
        </div>
        <p className="text-slate-600">Personalized insights to maximize your research earnings</p>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 mb-8 bg-white/60 backdrop-blur-sm rounded-xl p-1 w-fit border border-slate-200/60">
        {['overview', 'performance', 'recommendations'].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-6 py-3 rounded-lg text-sm font-medium transition-all duration-200 capitalize ${
              activeTab === tab
                ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg'
                : 'text-slate-600 hover:text-slate-800 hover:bg-slate-100/50'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-slate-200/60">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gradient-to-r from-emerald-100 to-emerald-50 rounded-xl">
                  <TrendingUp className="w-6 h-6 text-emerald-600" />
                </div>
                <span className="text-sm font-medium text-emerald-600 bg-emerald-100 px-2 py-1 rounded-full">+12%</span>
              </div>
              <h3 className="text-2xl font-bold text-slate-800 mb-1">$1,240</h3>
              <p className="text-slate-600 text-sm">Monthly Earnings</p>
            </div>

            <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-slate-200/60">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gradient-to-r from-blue-100 to-blue-50 rounded-xl">
                  <Target className="w-6 h-6 text-blue-600" />
                </div>
                <span className="text-sm font-medium text-blue-600 bg-blue-100 px-2 py-1 rounded-full">92%</span>
              </div>
              <h3 className="text-2xl font-bold text-slate-800 mb-1">4.8</h3>
              <p className="text-slate-600 text-sm">Average Rating</p>
            </div>

            <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-slate-200/60">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gradient-to-r from-purple-100 to-purple-50 rounded-xl">
                  <Activity className="w-6 h-6 text-purple-600" />
                </div>
                <span className="text-sm font-medium text-purple-600 bg-purple-100 px-2 py-1 rounded-full">+5</span>
              </div>
              <h3 className="text-2xl font-bold text-slate-800 mb-1">23</h3>
              <p className="text-slate-600 text-sm">Studies Completed</p>
            </div>
          </div>

          {/* AI Insights Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {insights.map((insight) => (
              <div key={insight.id} className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-slate-200/60 hover:border-indigo-300 transition-all duration-300">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-gradient-to-r from-indigo-100 to-purple-100 rounded-lg">
                      {insight.type === 'performance' && <BarChart3 className="w-5 h-5 text-indigo-600" />}
                      {insight.type === 'recommendations' && <Lightbulb className="w-5 h-5 text-indigo-600" />}
                      {insight.type === 'market' && <PieChart className="w-5 h-5 text-indigo-600" />}
                    </div>
                    <div>
                      <h3 className="font-semibold text-slate-800">{insight.title}</h3>
                      <p className="text-sm text-slate-600">{insight.description}</p>
                    </div>
                  </div>
                  <Sparkles className="w-5 h-5 text-indigo-500" />
                </div>

                {insight.type === 'performance' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-slate-600">Performance Score</span>
                      <span className="text-lg font-bold text-slate-800">{insight.score}/100</span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div className="bg-gradient-to-r from-indigo-500 to-purple-600 h-2 rounded-full" style={{ width: `${insight.score}%` }}></div>
                    </div>
                    <p className="text-sm text-slate-600">{insight.details}</p>
                  </div>
                )}

                {insight.type === 'recommendations' && (
                  <div className="space-y-3">
                    <div className="flex flex-wrap gap-2">
                      {insight.recommendations?.map((rec) => (
                        <span key={rec} className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-sm font-medium">
                          {rec}
                        </span>
                      ))}
                    </div>
                    <div className="flex items-center justify-between pt-2">
                      <span className="text-sm text-slate-600">Earning Potential</span>
                      <span className="text-sm font-semibold text-emerald-600">{insight.potential}</span>
                    </div>
                  </div>
                )}

                {insight.type === 'market' && (
                  <div className="space-y-3">
                    {insight.categories?.map((category) => (
                      <div key={category.name} className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm font-medium text-slate-700">{category.name}</span>
                            <span className="text-xs text-emerald-600 font-medium">{category.growth}</span>
                          </div>
                          <div className="w-full bg-slate-200 rounded-full h-1.5">
                            <div className="bg-gradient-to-r from-indigo-500 to-purple-600 h-1.5 rounded-full" style={{ width: `${category.demand}%` }}></div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Personalized Recommendations */}
          <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-slate-200/60">
            <h3 className="text-xl font-semibold text-slate-800 mb-4">Personalized Recommendations</h3>
            <div className="space-y-4">
              {personalizedRecommendations.map((rec) => (
                <div key={rec.id} className="flex items-center justify-between p-4 bg-slate-50/50 rounded-xl border border-slate-200/60">
                  <div className="flex-1">
                    <h4 className="font-medium text-slate-800 mb-1">{rec.title}</h4>
                    <p className="text-sm text-slate-600 mb-2">{rec.description}</p>
                    <div className="flex items-center space-x-4 text-xs text-slate-500">
                      <span>Impact: {rec.impact}</span>
                      <span>Time: {rec.timeToComplete}</span>
                      <span className="text-emerald-600 font-medium">{rec.potentialIncrease}</span>
                    </div>
                  </div>
                  <button className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 text-sm font-medium">
                    <span>Start</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'performance' && (
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 border border-slate-200/60 text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-indigo-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <BarChart3 className="w-8 h-8 text-indigo-600" />
          </div>
          <h3 className="text-xl font-medium text-slate-800 mb-3">Performance Analytics</h3>
          <p className="text-slate-600">
            Detailed performance metrics and trends coming soon
          </p>
        </div>
      )}

      {activeTab === 'recommendations' && (
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 border border-slate-200/60 text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-indigo-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Lightbulb className="w-8 h-8 text-indigo-600" />
          </div>
          <h3 className="text-xl font-medium text-slate-800 mb-3">Smart Recommendations</h3>
          <p className="text-slate-600">
            AI-powered career recommendations and skill development paths
          </p>
        </div>
      )}
    </div>
  );
}