import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Sparkles, TrendingUp, Clock, DollarSign, Users, Brain, Zap } from 'lucide-react';

const aiRecommendations = [
  {
    id: '1',
    title: 'AI-Powered Mobile Banking Study',
    description: 'Test our new AI-driven mobile banking interface with personalized recommendations',
    duration: '45 minutes',
    payment: 85,
    type: 'Remote',
    aiMatch: 95,
    tags: ['AI/ML', 'FinTech', 'Mobile UX'],
    urgency: 'high'
  },
  {
    id: '2',
    title: 'Voice UI Testing for Smart Assistant',
    description: 'Evaluate conversational AI interactions and voice command accuracy',
    duration: '60 minutes',
    payment: 120,
    type: 'Remote',
    aiMatch: 88,
    tags: ['Voice UI', 'AI Assistant', 'Accessibility'],
    urgency: 'medium'
  }
];

const regularStudies = [
  {
    id: '3',
    title: 'E-commerce Checkout Optimization',
    description: 'Help us improve our checkout process by testing the new user flow',
    duration: '30 minutes',
    payment: 50,
    type: 'Remote',
    tags: ['E-commerce', 'Conversion'],
    participants: 8,
    maxParticipants: 12
  },
  {
    id: '4',
    title: 'Healthcare App Usability',
    description: 'Test the usability of our new healthcare appointment booking system',
    duration: '40 minutes',
    payment: 65,
    type: 'Video call',
    tags: ['Healthcare', 'Booking'],
    participants: 5,
    maxParticipants: 10
  }
];

export default function Explore() {
  const [activeFilter, setActiveFilter] = useState('all');

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'bg-red-100 text-red-700 border-red-200';
      case 'medium': return 'bg-amber-100 text-amber-700 border-amber-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'Remote': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'Video call': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'In-person': return 'bg-purple-100 text-purple-700 border-purple-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="p-8 text-slate-800 min-h-screen">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent mb-2">
          Explore Opportunities
        </h1>
        <p className="text-slate-600">Discover AI-powered research opportunities tailored for you</p>
      </div>

      {/* AI Recommendations */}
      <div className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-2xl font-semibold text-slate-800">AI Recommendations</h2>
            <div className="px-3 py-1 bg-gradient-to-r from-emerald-100 to-emerald-50 border border-emerald-200 rounded-full">
              <span className="text-xs font-medium text-emerald-700">Powered by AI</span>
            </div>
          </div>
          <div className="flex space-x-2">
            <button className="p-2 rounded-lg bg-white/80 hover:bg-white border border-slate-200 transition-all duration-200 hover:shadow-md">
              <ChevronLeft className="w-5 h-5 text-slate-600" />
            </button>
            <button className="p-2 rounded-lg bg-white/80 hover:bg-white border border-slate-200 transition-all duration-200 hover:shadow-md">
              <ChevronRight className="w-5 h-5 text-slate-600" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {aiRecommendations.map((study) => (
            <div key={study.id} className="group relative bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-slate-200/60 hover:border-indigo-300 transition-all duration-300 hover:shadow-xl hover:shadow-indigo-500/10">
              <div className="absolute top-4 right-4 flex items-center space-x-2">
                <div className="flex items-center space-x-1 px-2 py-1 bg-gradient-to-r from-indigo-100 to-purple-100 border border-indigo-200 rounded-full">
                  <Sparkles className="w-3 h-3 text-indigo-600" />
                  <span className="text-xs font-medium text-indigo-700">{study.aiMatch}% match</span>
                </div>
                <div className={`px-2 py-1 border rounded-full text-xs font-medium ${getUrgencyColor(study.urgency)}`}>
                  {study.urgency} priority
                </div>
              </div>

              <div className="mb-4 pr-32">
                <h3 className="text-lg font-semibold text-slate-800 mb-2 group-hover:text-indigo-700 transition-colors">
                  {study.title}
                </h3>
                <p className="text-slate-600 text-sm leading-relaxed">
                  {study.description}
                </p>
              </div>

              <div className="flex flex-wrap gap-2 mb-4">
                {study.tags.map((tag) => (
                  <span key={tag} className="px-2 py-1 bg-slate-100 text-slate-700 rounded-lg text-xs font-medium">
                    {tag}
                  </span>
                ))}
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4 text-sm text-slate-600">
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{study.duration}</span>
                  </div>
                  <div className="flex items-center space-x-1 text-emerald-600 font-semibold">
                    <DollarSign className="w-4 h-4" />
                    <span>${study.payment}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <span className={`px-3 py-1 border rounded-full text-xs font-medium ${getTypeColor(study.type)}`}>
                    {study.type}
                  </span>
                  <button className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 text-sm font-medium shadow-lg shadow-indigo-500/25">
                    Apply Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-slate-200/60">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <TrendingUp className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-slate-600">Active Studies</p>
              <p className="text-xl font-bold text-slate-800">24</p>
            </div>
          </div>
        </div>
        <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-slate-200/60">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-emerald-100 rounded-lg">
              <DollarSign className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-sm text-slate-600">Avg. Payout</p>
              <p className="text-xl font-bold text-slate-800">$67</p>
            </div>
          </div>
        </div>
        <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-slate-200/60">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Users className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-slate-600">Participants</p>
              <p className="text-xl font-bold text-slate-800">1.2k</p>
            </div>
          </div>
        </div>
        <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-slate-200/60">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-indigo-100 rounded-lg">
              <Zap className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <p className="text-sm text-slate-600">AI Matches</p>
              <p className="text-xl font-bold text-slate-800">89%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Regular Studies */}
      <div className="mb-12">
        <h2 className="text-2xl font-semibold text-slate-800 mb-6">All Studies</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {regularStudies.map((study) => (
            <div key={study.id} className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-slate-200/60 hover:border-slate-300 transition-all duration-300 hover:shadow-lg">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-slate-800 mb-2">{study.title}</h3>
                  <p className="text-slate-600 text-sm mb-3 leading-relaxed">
                    {study.description}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mb-4">
                {study.tags.map((tag) => (
                  <span key={tag} className="px-2 py-1 bg-slate-100 text-slate-700 rounded-lg text-xs font-medium">
                    {tag}
                  </span>
                ))}
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4 text-sm text-slate-600">
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{study.duration}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="w-4 h-4" />
                    <span>{study.participants}/{study.maxParticipants}</span>
                  </div>
                  <div className="flex items-center space-x-1 text-emerald-600 font-semibold">
                    <DollarSign className="w-4 h-4" />
                    <span>${study.payment}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <span className={`px-3 py-1 border rounded-full text-xs font-medium ${getTypeColor(study.type)}`}>
                    {study.type}
                  </span>
                  <button className="px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-900 transition-colors text-sm font-medium">
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}