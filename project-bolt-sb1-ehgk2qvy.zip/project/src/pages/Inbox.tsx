import React from 'react';
import { Mail, Clock } from 'lucide-react';

const mockMessages = [
  {
    id: '1',
    from: 'FinTech Solutions',
    subject: 'Mobile Banking Study - Session Confirmed',
    preview: 'Your session for January 20th at 2:00 PM has been confirmed. Please find the meeting details...',
    time: '2 hours ago',
    unread: true
  },
  {
    id: '2',
    from: 'Research Team',
    subject: 'Payment Processed - $50.00',
    preview: 'Your payment for the E-commerce Checkout Flow study has been processed successfully...',
    time: '1 day ago',
    unread: false
  },
  {
    id: '3',
    from: 'SocialTech',
    subject: 'New Study Invitation',
    preview: 'We would like to invite you to participate in our upcoming social media app testing session...',
    time: '3 days ago',
    unread: true
  }
];

export default function Inbox() {
  return (
    <div className="p-8 text-white">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-4">Inbox</h1>
        <p className="text-gray-400">Messages and notifications from research teams</p>
      </div>

      <div className="bg-gray-800 rounded-2xl overflow-hidden">
        {mockMessages.length > 0 ? (
          <div className="divide-y divide-gray-700">
            {mockMessages.map((message) => (
              <div
                key={message.id}
                className={`p-6 hover:bg-gray-750 transition-colors cursor-pointer ${
                  message.unread ? 'bg-gray-750' : ''
                }`}
              >
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 bg-gray-600 rounded-full flex items-center justify-center">
                      <Mail className="w-5 h-5 text-gray-300" />
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className={`text-sm font-medium ${
                        message.unread ? 'text-white' : 'text-gray-300'
                      }`}>
                        {message.from}
                      </h3>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-gray-400">{message.time}</span>
                        {message.unread && (
                          <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        )}
                      </div>
                    </div>
                    <h4 className={`text-sm mb-2 ${
                      message.unread ? 'text-white font-medium' : 'text-gray-300'
                    }`}>
                      {message.subject}
                    </h4>
                    <p className="text-sm text-gray-400 line-clamp-2">
                      {message.preview}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center">
            <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mail className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-xl font-medium text-gray-300 mb-3">No messages yet</h3>
            <p className="text-gray-400">
              Messages from research teams will appear here
            </p>
          </div>
        )}
      </div>
    </div>
  );
}