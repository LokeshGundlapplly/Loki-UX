import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Camera, Edit3, MapPin, Calendar, Star, Award } from 'lucide-react';

export default function Profile() {
  const { user, logout } = useAuth();
  const [isEditing, setIsEditing] = useState(false);

  const stats = {
    studiesCompleted: 12,
    totalEarnings: 850,
    averageRating: 4.8,
    responseRate: 95
  };

  return (
    <div className="p-8 text-white">
      <div className="max-w-4xl mx-auto">
        {/* Profile Header */}
        <div className="bg-gray-800 rounded-2xl p-8 mb-8">
          <div className="flex items-start space-x-6">
            <div className="relative">
              <img
                src={user?.avatar || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2'}
                alt={user?.name}
                className="w-24 h-24 rounded-full border-4 border-gray-600"
              />
              <button className="absolute bottom-0 right-0 p-2 bg-blue-600 text-white rounded-full shadow-lg hover:bg-blue-700 transition-colors">
                <Camera className="w-4 h-4" />
              </button>
            </div>
            
            <div className="flex-1">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h1 className="text-2xl font-bold text-white mb-1">{user?.name}</h1>
                  <p className="text-gray-400">UX Research Participant</p>
                </div>
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className="flex items-center space-x-2 px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors"
                >
                  <Edit3 className="w-4 h-4" />
                  <span>Edit Profile</span>
                </button>
              </div>
              
              <div className="flex items-center space-x-6 text-sm text-gray-400">
                <div className="flex items-center space-x-1">
                  <MapPin className="w-4 h-4" />
                  <span>San Francisco, CA</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Calendar className="w-4 h-4" />
                  <span>Joined January 2025</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-gray-800 rounded-xl p-6 text-center">
            <div className="text-2xl font-bold text-white mb-1">{stats.studiesCompleted}</div>
            <div className="text-sm text-gray-400">Studies Completed</div>
          </div>
          <div className="bg-gray-800 rounded-xl p-6 text-center">
            <div className="text-2xl font-bold text-blue-400 mb-1">${stats.totalEarnings}</div>
            <div className="text-sm text-gray-400">Total Earnings</div>
          </div>
          <div className="bg-gray-800 rounded-xl p-6 text-center">
            <div className="flex items-center justify-center space-x-1 mb-1">
              <Star className="w-5 h-5 text-blue-400 fill-current" />
              <span className="text-2xl font-bold text-white">{stats.averageRating}</span>
            </div>
            <div className="text-sm text-gray-400">Average Rating</div>
          </div>
          <div className="bg-gray-800 rounded-xl p-6 text-center">
            <div className="text-2xl font-bold text-white mb-1">{stats.responseRate}%</div>
            <div className="text-sm text-gray-400">Response Rate</div>
          </div>
        </div>

        {/* Profile Details */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* About */}
          <div className="bg-gray-800 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">About</h3>
            <p className="text-gray-300 leading-relaxed mb-4">
              Passionate UX researcher with 3+ years of experience in user testing and feedback. 
              I specialize in mobile app usability, e-commerce flows, and accessibility testing.
            </p>
            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-sm text-gray-400">
                <span className="font-medium">Email:</span>
                <span>{user?.email}</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-400">
                <span className="font-medium">Phone:</span>
                <span>+1 (555) 123-4567</span>
              </div>
            </div>
          </div>

          {/* Skills & Expertise */}
          <div className="bg-gray-800 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Skills & Expertise</h3>
            <div className="flex flex-wrap gap-2 mb-6">
              {['Mobile UX', 'Web Usability', 'E-commerce', 'Accessibility', 'User Research', 'Prototyping'].map((skill) => (
                <span
                  key={skill}
                  className="px-3 py-1 bg-blue-600 text-blue-100 rounded-full text-sm"
                >
                  {skill}
                </span>
              ))}
            </div>
            
            <h4 className="text-md font-medium text-white mb-3">Achievements</h4>
            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-sm text-gray-300">
                <Award className="w-4 h-4 text-blue-400" />
                <span>Top Rated Participant</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-300">
                <Award className="w-4 h-4 text-blue-400" />
                <span>Quick Responder Badge</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-300">
                <Award className="w-4 h-4 text-blue-400" />
                <span>Detailed Feedback Award</span>
              </div>
            </div>
          </div>
        </div>

        {/* Account Actions */}
        <div className="mt-8 bg-gray-800 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Account Settings</h3>
          <div className="flex flex-wrap gap-4">
            <button className="px-4 py-2 bg-gray-700 text-gray-300 rounded-lg hover:bg-gray-600 transition-colors">
              Change Password
            </button>
            <button className="px-4 py-2 bg-gray-700 text-gray-300 rounded-lg hover:bg-gray-600 transition-colors">
              Notification Settings
            </button>
            <button className="px-4 py-2 bg-gray-700 text-gray-300 rounded-lg hover:bg-gray-600 transition-colors">
              Payment Methods
            </button>
            <button
              onClick={logout}
              className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
            >
              Sign Out
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}